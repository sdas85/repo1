import boto3
import time
aws_con = boto3.session.Session(profile_name='ilevel2')
aws_ssm_cli = aws_con.client(service_name="ssm", region_name="us-east-1")

with open(r'C:\Users\sandip.das\OneDrive - IHS Markit\Documents\QA-INST-ID.txt') as fp:
    InstIds = [line.rstrip() for line in fp.readlines() if line.rstrip()]


response = aws_ssm_cli.send_command(
    InstanceIds=InstIds,
    DocumentName="AWS-RunPowerShellScript",
    Parameters={
        "commands": [
            "C:\AutomatedTests\Scripts\set-dns-local.ps1"
        ]
    }
)

command_id = response['Command']['CommandId']
print(command_id)



