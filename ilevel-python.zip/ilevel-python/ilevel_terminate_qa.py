import boto3
import json
import time

aws_con = boto3.session.Session(profile_name='ilevel2')
ec2_con_cli = aws_con.client(service_name="ec2", region_name="us-east-1")


with open(r'C:\Users\sandip.das\OneDrive - IHS Markit\Documents\QA-INST.txt') as fp:
    lines = [line.rstrip() for line in fp.readlines() if line.rstrip()]

inst_ids = []
for line in lines:
    TagName, IpAddress = line.split("\t")
    f1 = {"Name": "tag:Name", "Values": [TagName]}
    for inst in ec2_con_cli.describe_instances(Filters=[f1])['Reservations']:
        for details in inst['Instances']:
            if 'PrivateIpAddress' in details:
                if details['PrivateIpAddress'] == IpAddress:
                    inst_id = details['InstanceId']
                    inst_ids.append(inst_id)

print("Instance Termination list = {}".format(inst_ids))

### Terminate Instances

waiter = ec2_con_cli.get_waiter('instance_terminated')
print("Terminating Instances....")
ec2_con_cli.terminate_instances(InstanceIds=inst_ids)
waiter.wait(InstanceIds=inst_ids)
print("Instances are terminated")