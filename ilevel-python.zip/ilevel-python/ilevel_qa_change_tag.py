import boto3
import time

aws_con = boto3.session.Session(profile_name='ilevel2')
ec2_con_cli = aws_con.client(service_name="ec2", region_name="us-east-1")


with open(r'C:\Users\sandip.das\OneDrive - IHS Markit\Documents\QA-INST.txt') as fp:
    lines = [line.rstrip() for line in fp.readlines() if line.rstrip()]


for line in lines:
    TagName, IpAddress = line.split("\t")
    f1 = {"Name": "tag:Name", "Values": [TagName]}
    for inst in ec2_con_cli.describe_instances(Filters=[f1])['Reservations']:
        for details in inst['Instances']:
            if 'PrivateIpAddress' in details:
                if details['PrivateIpAddress'] == IpAddress:
                    inst_id = details['InstanceId']
                    for tag in details['Tags']:
                        if tag['Key'] == 'Env':
                            print("Changing Tag {} on Instance {}".format(tag,inst_id))
                            resp = ec2_con_cli.create_tags(
                                Resources=[inst_id],
                                Tags=[
                                    {
                                        'Key': 'Env',
                                        'Value': 'QA-AUTOTEST-US-OLD'
                                    }
                                ]
                            )
